package item_exam1;

public class Item {
	

	public Object getPrice() {
		// TODO Auto-generated method stub
		int Bag=1000;
		return Bag;
	}
	
	public Object getdisp() {
		String mobile1;
		// TODO Auto-generated method stub
		mobile1= "Mobile";
			return mobile1;
	}

}
