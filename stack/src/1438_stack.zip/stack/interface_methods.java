package stack;

public interface interface_methods{
	void push(int number);
	void  pop();
	 void get_top();
	boolean isempty();
	void display();

}
