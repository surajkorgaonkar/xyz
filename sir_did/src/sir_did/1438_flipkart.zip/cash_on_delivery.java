package sir_did;

public class cash_on_delivery implements paymentmethod {

	@Override
	public void makepayment(Item item) {
		// TODO Auto-generated method stub
		System.out.println("payment method= cash on delivery");
		System.out.println("Item purchased=" );

	}

}
