package sir_did;

public interface paymentmethod {

	void makepayment(Item item);

}
