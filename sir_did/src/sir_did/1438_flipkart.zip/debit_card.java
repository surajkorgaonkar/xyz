package sir_did;

public class debit_card implements paymentmethod {

	@Override
	public void makepayment(Item item) {
		// TODO Auto-generated method stub
		System.out.println("payment method= Debit card.");
		System.out.println("Item purchased=" );
	}

}
